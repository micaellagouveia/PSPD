# WordCount - Adaptação para Contagem de Amizades

Aplicação Hadoop que faz a contagem de amizades.
É utilizado o mesmo docker da etapa anterior, mas como o arquivo WordCOunt foi alterado, é necessário dar outro build na aplicação para rodar a etapa 2.

## Como rodar
1. ```docker-compose up```
2. Resultado sairá no path ```src/io/output/part-r-00000```
