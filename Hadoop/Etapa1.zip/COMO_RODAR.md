# WordCount

Aplicação Hadoop que faz a contagem das palavras em um arquivo.


## Como rodar
1. ```docker-compose up```
2. Resultado sairá no path ```src/io/output/part-r-00000```
