# Twitter Stream usando Docker

Solução utilizada para teste do Kafka Connect. Foi utilizado um projeto antigo que já possuia as configurações do Kafka, Kafka-connect, ElasticSearch e Kibana para fazer o teste do Kafka-connect no projeto.

## Arquivos src/
- producer.py: Produtor de mensagens do Twitter relacionados ao Lula
- producer2.py: Produtor de mensagens do Twitter relacionados ao Bolsonaro
- consumer.py: Consumidor de mensagens do Twitter relacionados ao Lula
- consumer2.py: Consumidor de mensagens do Twitter relacionados ao Bolsonaro

## Passo a passo para rodar e testar
1. Subir o zookeeper: ```docker compose up -d zookeeper```
2. Subir o kafka: ```docker compose up -d kafka```
3. Subir o kafka-connect: ```docker compose up -d kafka-connect1```
4. Subir o control-center: ```docker compose up -d control-center```
    O control-center é uma interface gráfica para visualização do Kafka. Basta apenas rodar na ```localhost:9021```

5. Subir os produtores: ```docker compose up -d producer producer2```
6. Subir os consumidores: ```docker compose up -d consumer consumer2```
7. Subir o elasticSearch: ```docker compose up -d elasticsearch```
8. Esperar uns 20 segundos e subir o Kibana: ```docker compose up -d kibana```

No control-center é possível ver o cluster atio, seus tópicos, as mensagens que os tópicos estão recebendo,
além de conseguir visualizar o connect. É possível criar a conexão seguindo os seguintes passos:

1. Entre no Kafka Control Center, usando a porta 0.0.0.0:9021, e carregue o arquivo do connector do elasticsearch (es-skink.properties).
2. Para isso clique na Aba `Connect` na barra lateral, clique em connect-default, clique em `Add Connector`, clique em `Upload connector config file`, e selecione o arquivo es-skink.properties.
3. Confirme a criação. A execução do Kafka Connect é um processo sem fim, sempre que um dado for transformado, o dado será carregado no ElasticSearch. 

Para visualização no Kibana:
1. Acesse o kibana utilizado a porta 0.0.0.0:5601. Utilize as credenciais: elastic e changeme.
2. Clique em `Explore on my own`. No menu lateral direito, acesse a aba de Dashboard.
3. Clique em `Create new Dashboard`. Clique em Create index pattern. Digite no campo name `lula_treated_messages.*`.
4. Clique em `Create Index Pattern`. Volte para a aba do dashboard. Clique em Create Visualization. Arraste algum dos campos da esquerda para a sessão `Drop some fields here to start` e configure o gráfico como desejar.
5. Clique em `Save and return`. Uma vez que os gráficos estão prontos, clique em `Save` e dê um nome para o dashboard


